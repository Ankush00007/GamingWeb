
let x=document.getElementById("li1");
let y=document.getElementById("rules");
console.log(x);
console.log(y);
function change(){
    y.innerHTML=" hi";
}



// function color() {
//     var element = document.getElementById("myDIV");
//     element.classList.toggle("rules");
//  }